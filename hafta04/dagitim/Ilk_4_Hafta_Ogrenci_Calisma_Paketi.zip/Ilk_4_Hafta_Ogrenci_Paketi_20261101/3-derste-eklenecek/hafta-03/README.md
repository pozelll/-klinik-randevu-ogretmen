# Üçüncü ders - öğrenci başlangıç ekleri
29 Ekim 2026. Aynı Klinik Randevu projesinin devamı. G01/G02/G03: 5 kişi; G04: 4 kişi.
Öğretmen örneği: https://github.com/pozelll/-klinik-randevu-ogretmen - Public.

1. Bu hafta-03 klasörünü ilk iki derste çalıştığınız projenin köküne ekleyin. Eski docs ve index.html korunur.
2. PDF'nin üçüncü ders bölümünü izleyin. 13 boş belgeyi kendi sonuçlarınızla doldurun.
3. Altı aday iş kartını okuyun; GitHub'da bu derste H3-01, H3-02 ve H3-03 için üç gerçek Issue açın. H3-04/05/06 aday olarak belgede kalır.
4. Pano Status: Todo / In Progress / Done. Sprint H3-S1 belgedeki çalışma etiketidir; ek GitHub alanı zorunlu değildir.
5. kod-parcalari içindeki iki TXT dosyası uygulama desteğidir. Kendi mevcut kök index.html dosyanıza bir kez uygulayın. Referans kopyayı ikinci bir ürün olarak düzenlemeyin.
6. Aynı tarayıcı ve dosya yolunda çalışın. Önceki kayıtları sıfırlamayın; kendi gerçek kayıt kimliklerinizi yazın.
7. Testte gözlenen sonucu ancak çalıştırdıktan sonra doldurun. İnceleme yoksa Bekliyor; iş Done değildir.
8. ders-testi.html çevrimdışı ek alıştırmadır. 13-cikis-bileti.md dosyasındaki altı açık soruyu da her üye ayrı cevaplar.

Önceki proje yoksa referans-uygulama başlangıç kopyası kullanılabilir; bu seçimi kaydedin. İnternet engelinde belgeleri yerelde doldurun, GitHub aktarımını Bekliyor yazın.
