# Ekip ve ürün hedefi
Grup / tarih: [ ]
Mevcut grup deposu: [ ]
Kullanılan aynı yerel index.html yolu: [ ]
Ürün hedefi: [Kullanıcıya sağlanacak fayda]
Kapsam / kapsam dışı: [ ]

| Üye | Ad ve GitHub adı | Temsil edilen bakış / görev | Somut katkı |
|---|---|---|---|
| 1 | [ ] | Ürün önceliği / Product Owner bakışı | [ ] |
| 2 | [ ] | Plan, pano, engeller / Scrum Master bakışı | [ ] |
| 3 | [ ] | H3-01 ve H3-02 uygulama / Developer | [ ] |
| 4 | [ ] | Test ve kanıt / Developer | [ ] |
| 5 | [ ] | Bağımsız kod incelemesi ve teslim / Developer | [ ] |

G04 dört kişidir: Üye 1 ürün + teslim; Üye 2 plan + bağımsız kod incelemesi; Üye 3 kod; Üye 4 test. Beşinci satır kullanılmaz. Kod yazan kendi kodunun bağımsız inceleyeni değildir. İlk iki derse göre görev dönüşümü: [ ]
Bu görev dağılımı bir sınıf simülasyonudur; bütün öğrenciler somut çıktıya katkı verir.
