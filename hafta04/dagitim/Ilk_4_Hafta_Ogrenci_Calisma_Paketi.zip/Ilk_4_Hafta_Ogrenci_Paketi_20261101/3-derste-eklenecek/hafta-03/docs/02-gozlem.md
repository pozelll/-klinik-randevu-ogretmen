# Başlangıç gözlemi

Başlangıç sürümü / dosya: [ ]
Ortam ve tarayıcı: [ ]
İzlenen yol: Sıfırla > Hasta/Ece/Deniz/12 Kasım 2030 > R001 İptal et > Vazgeç.
Gözlem: [Kendin gördüğünü yaz]
Geliştirme ihtiyacı: [Gözlemden ayrı yaz]
FR bağlantısı: [ ]
Doğrulanmamış varsayım: [ ]
