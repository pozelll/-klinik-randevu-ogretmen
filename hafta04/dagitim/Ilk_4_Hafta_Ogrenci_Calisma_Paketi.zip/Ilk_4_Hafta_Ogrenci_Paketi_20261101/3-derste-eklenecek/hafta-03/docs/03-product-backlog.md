# Ürün iş listesi

İlk ve güncel tahmini ayrı tut. Gerçek issue URL’lerini gir; sayısal GitHub numaraları örnekteki H3 kimlikleri değildir.

| İş | Başlık | Bağlantı | İlk puan | Güncel puan | Bağımlılık | Sıra | Issue URL |
| --- | --- | --- | --- | --- | --- | --- | --- |
| H3-01 | İptal koşulunu görünür yap | FR-03 | 2 | 2 | Yok | [Sıra] | [URL] |
| H3-02 | Onay penceresinde sonucu açıkla | FR-03 / BR-01 | 3 | 3 | H3-01 ile ortak metin kararı | [Sıra] | [URL] |
| H3-03 | Saat seçimine kısa yardım ekle | FR-01 / FR-02 | 3 | 3 | Yok | [Sıra] | [URL] |
| H3-04 | Randevuyu başka saate taşı | Yeni aday gereksinim | 8 | 8 | FR-02 / FR-03 ve yeni iş kuralı | [Sıra] | [URL] |
| H3-05 | SMS ile hatırlatma gönder | Yeni aday gereksinim | 8 | 8 | Sunucu, sağlayıcı ve izin tasarımı | [Sıra] | [URL] |
| H3-06 | Doktorlar arası özet görünümü | FR-06 genişletmesi | 5 | 5 | Özet kapsamı ve erişim kararı | [Sıra] | [URL] |

İlk iki tercihin gerekçesi: [ ]
