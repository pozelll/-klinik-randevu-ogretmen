# Kabul koşulları ve Bitti Tanımı

## İşe özel kabul koşulları

| Koşul | İş | Verilen durum | İşlem | Beklenen sonuç |
| --- | --- | --- | --- | --- |
| H3-AC01 | H3-01 | [ ] | [ ] | [ ] |
| H3-AC02 | H3-01 | [ ] | [ ] | [ ] |
| H3-AC03 | H3-02 | [ ] | [ ] | [ ] |
| H3-AC04 | H3-02 | [ ] | [ ] | [ ] |
| H3-AC05 | H3-01 | [ ] | [ ] | [ ] |

## Ortak Bitti Tanımı

| Ortak kalite koşulu | Hangi kanıt gerekli | H3-01 durumu | H3-02 durumu |
| --- | --- | --- | --- |
| [1] | [ ] | Bekliyor | Bekliyor |
| [2] | [ ] | Bekliyor | Bekliyor |
| [3] | [ ] | Bekliyor | Bekliyor |
| [4] | [ ] | Bekliyor | Bekliyor |
| [5] | [ ] | Bekliyor | Bekliyor |

Kapsamın güvenlik sınırı: [ ]
Son karar ve gerekçe: [ ]

Koşul kapsamları: AC01 kendi Bekliyor kaydı; AC02 kayıt korunması ve koşullu saat açılması; AC03 kimlik/tarih/saat ve onay açıklaması; AC04 vazgeçme-iptal ve sabit toplam; AC05 Tamamlandı sınırı. Kendi Verilen/İşlem/Beklenen cümlelerinizi yazın.
