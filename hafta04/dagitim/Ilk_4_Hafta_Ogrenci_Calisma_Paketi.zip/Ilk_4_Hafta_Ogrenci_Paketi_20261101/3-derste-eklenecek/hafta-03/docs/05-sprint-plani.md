# Sprint planı

Sprint etiketi: H3-S1
Ürün hedefi: [ ]
Sprint hedefi: [ ]
Hedefin gözlem sorusu: [ ]
Kapasite: 8 göreli puan; bu ders için verilmiş varsayım, ölçülmüş hız değildir.

## İlk plan

Seçilen işler ve puanlar: [ ]
Toplam: [ ]
Hedefle ilişkisi: [ ]
Bağımlılık: [ ]

| İş | Küçük görev | Sorumlu | Planlanan kanıt |
| --- | --- | --- | --- |
| H3-01 | [ ] | [ ] | [ ] |
| H3-02 | [ ] | [ ] | [ ] |
| H3-03 | [ ] | [ ] | [ ] |

## Yeni bilgi sonrası güncel plan

Değişikliğin nedeni: [ ]
Güncel seçim ve toplam: [ ]
Ertelenen iş ve nedeni: [ ]
Hedef neden korunuyor: [ ]
Kalite nasıl korunuyor: [ ]
