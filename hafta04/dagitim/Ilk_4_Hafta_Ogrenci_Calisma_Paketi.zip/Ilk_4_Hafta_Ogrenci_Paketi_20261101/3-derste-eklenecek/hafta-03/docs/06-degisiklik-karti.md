# Değişiklik kartı

Rehberin Adım 15 bölümüne gelince açın.

Eğitim paydaşı yeni bilgi verdi: “Tamamlandı randevunun iptal edilemediğini ana açıklamada da okuyabilmeliyim.”

Verilen ek çalışma: H3-01 metnine bu koşul ve R003 kontrolü eklenir. Simülasyonda H3-01 tahmini 2'den 3'e güncellenir. İlk tahmin korunacaktır. Diğer tahminler ve kapasite değişmez.

| Karar alanı | Ekibin cevabı |
| --- | --- |
| İlk kapsamın yeni toplamı | [ ] |
| Kapasiteyle fark | [ ] |
| Hedefe temel katkı veren işler | [ ] |
| Ertelenebilecek iş | [ ] |
| Product Owner ve Developers ortak kararı | [ ] |
| Bitti Tanımı etkisi | [ ] |
| Panoda değişen alanlar | [ ] |

Bu kart yaşanmış kullanıcı şikâyeti değil, derste verilen senaryodur.
