# Pano ve günlük plan kontrolü
Projects URL: [ ]
Status: Todo / In Progress / Done
Çalışma etiketi: H3-S1 (bu belgedeki etiket; ek GitHub Sprint alanı zorunlu değil)
Çalışma anlaşması: In Progress içinde en çok iki H3 kartı.

| İş | Gerçek Issue URL | İlk durum | Güncel durum | Erteleme / karar |
|---|---|---|---|---|
| H3-01 | [ ] | Todo | [ ] | [ ] |
| H3-02 | [ ] | Todo | [ ] | [ ] |
| H3-03 | [ ] | Todo | [ ] | [ ] |

H3-04/05/06 ürün iş listesinde adaydır; bu derste gerçek Issue açmak zorunlu değildir.
Gerçek görüşme tarihi ve katılanlar: [ ]
Hedef için ilerleme: [ ]
Engel / destek: [ ]
Karar / sorumlu / sonraki adım: [ ]
İnternet yoksa bu tablo çevrimdışı panodur. Aktarım bekliyor: [ ]
