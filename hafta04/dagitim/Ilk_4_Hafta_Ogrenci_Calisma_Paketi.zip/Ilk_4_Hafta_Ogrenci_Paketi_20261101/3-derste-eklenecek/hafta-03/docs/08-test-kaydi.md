# Gerçek test kaydı
Tarih/saat: [ ] | Test eden: [ ] | Tarayıcı/sürüm: [ ] | İşletim sistemi: [ ]
Dosya yolu ve sürümü/commit: [ ]
Önceki kayıtları koruyun. Kendi kaydınızın kimliğini yazın; öğretmenin R013 numarasını üretmeye çalışmayın.

| Test | Önkoşul ve işlem | Beklenen | Gözlenen | Durum | Kanıt |
|---|---|---|---|---|---|
| T01 | Hasta rolü, ana açıklamayı oku. | Kendi Bekliyor kaydı, Tamamlandı sınırı, kaydın kalması ve koşullu saat açılması görünür. | [ ] | Çalıştırılmadı | [ ] |
| T02 | Kendi Bekliyor kaydını not et; İptal et, pencerede İptal/Cancel ile vazgeç. | Kimlik/tarih/saat açıklanır; kayıt Bekliyor, saat Dolu ve toplam korunur. | [ ] | Çalıştırılmadı | [ ] |
| T03 | T02'deki kayıtta İptal et; Tamam/OK ile onayla. | Kayıt İptal edildi olarak kalır; başka iptal edilmemiş kayıt yoksa saat Uygun; toplam değişmez. | [ ] | Çalıştırılmadı | [ ] |
| T04 | Kendi Tamamlandı kaydını ve saatini incele; başlangıçta Ece R003 / 11:00 örneği vardır. | Hasta için iptal düğmesi yok; saat Kapalı. | [ ] | Çalıştırılmadı | [ ] |
| T05 | Önce Ece adına Bekliyor kayıt belirle; Kaan görünümüne geç. | Ece'nin kaydı Kaan listesinde yok; o saat Dolu; Kaan'ın kayıtları görünür. | [ ] | Çalıştırılmadı | [ ] |
| T06 | Uygun saatte oluştur, pencerede iptalden vazgeç, sonra iptali onayla; her aşamada toplamları oku. | Yeni kayıtla toplam +1; vazgeçmede durum/sayı korunur; iptal sonrası toplam sabit, Bekliyor -1, İptal +1. | [ ] | Çalıştırılmadı | [ ] |

## T06 sayım tablosu
Aynı doktor ve tarih; sayımları Resepsiyon rolünde okuyun. Her işlem için Hasta rolüne dönüp aynı seçimleri kurun.

| Aşama | Bekliyor | Tamamlandı | İptal edildi | Toplam | Kayıt kimliği / saat |
|---|---|---|---|---|---|
| Önce | [ ] | [ ] | [ ] | [ ] | [ ] |
| Oluşturma sonrası | [ ] | [ ] | [ ] | [ ] | [ ] |
| Vazgeçme sonrası | [ ] | [ ] | [ ] | [ ] | [ ] |
| Onaylı iptal sonrası | [ ] | [ ] | [ ] | [ ] | [ ] |

T05 için bekleyen Ece kaydı kalmadıysa uygun saate bir tane oluşturun; bu hazırlığı ve sayılara etkisini kaydedin. Veriyi sıfırlamayın.
Yanlış düğme seçilirse gerçek eylemi yazın; yeni tekrarı ayrı satırda kaydedin. UI görünümü gerçek sunucu yetkilendirmesi testi değildir.
Bulgu / düzeltme / tekrar test sürümü: [ ]
Birleştirme sonrası kısa kontrol: [ ]
NFR ölçümü yapılmadıysa: Ölçülmedi.
