# PR ve arkadaş incelemesi

Önerilen başlık: H3 iptal koşulu ve onay açıklaması
base: main (ekibin gerçek ana dalı farklıysa kaydet)
compare: feat/h3-iptal-acikligi

## PR gövdesi

Sorun: [Başlangıçta hangi bilgi eksikti?]
Değişiklik: [İki küçük düzenleme]
Kabul koşulları: [Kimlikler]
Test: [Gerçek sonuçların dosya bağlantısı ve çalıştırılan sürüm]
İlgili işler: [H3-01 gerçek URL] [H3-02 gerçek URL]
Kalan iş: H3-03; tamamlanmadı, Todo ve ertelendi.
Bilinen sınır: [ ]

## İnceleme kaydı

PR URL: [ ]
İnceleyen: [Gerçek başka kişi; yoksa bekliyor]
İncelenen commit: [ ]
Somut gözlem: [ ]
Düzeltme isteği / karar: [ ]
Yanıt ve düzeltme commit'i: [ ]
Merge commit: [Gerçekleşince doldur]

Önceki belge PR'ı henüz birleşmediyse taban dalı öğretmenle netleştirin. Öğretmenin örnek PR #7 ve #11 durumu grup deponuzdaki PR numaraları değildir.
