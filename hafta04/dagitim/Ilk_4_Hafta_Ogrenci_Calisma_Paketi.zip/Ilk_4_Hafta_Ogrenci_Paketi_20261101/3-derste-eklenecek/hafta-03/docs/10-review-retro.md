# Review ve retrospektif

## Review ürün sonucunu inceler

Paydaş rolünü canlandıran kişi: [ ]
Gösterilen sürüm: [ ]
Sorulan soru: [ ]
Gerçek sınıf yanıtı: [ ]
Backlog kararı ve gerekçe: [ ]
Bu sınıf provası gerçek hasta araştırması değildir.

## Retrospektif çalışma biçimini inceler

İşe yarayan uygulama: [ ]
Gözlenen süreç sorunu: [ ]
Sonraki uygulamada tek deneme: [ ]
Sorumlu: [ ]
Ne zaman: [ ]
Başarı kontrolü: [ ]
