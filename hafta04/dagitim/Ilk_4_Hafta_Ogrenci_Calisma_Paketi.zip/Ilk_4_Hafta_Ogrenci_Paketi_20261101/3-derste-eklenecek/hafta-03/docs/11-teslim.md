# Teslim kontrolü

Ekip / tarih: [ ]
Depo URL: [ ]
Projects URL: [ ]
PR URL: [ ]
Merge veya son çalışma commit URL: [ ]
Ana dal adı: [ ]

- [ ] Doldurulmuş 13 Markdown dosyası.
- [ ] Gerçek üç H3 Issue bağlantısı (H3-01/02/03); diğer üç iş aday; internet engelinde açıkça bekliyor kaydı.
- [ ] İlk ve güncel sprint planı.
- [ ] H3-01 ve H3-02 kod değişikliği.
- [ ] T01–T06 gerçek test kaydı; yapılmayanlar Çalıştırılmadı.
- [ ] Gerçek arkadaş incelemesi; eksikse bekliyor.
- [ ] E01–E04 kendi ekran kanıtlarım.
- [ ] Öğretmen depo ve panoya ayrı ayrı erişebiliyor.
- [ ] Her öğrenci için ayrı bireysel çıkış bileti; isteğe bağlı çevrimdışı alıştırmanın ilk sonucu.
- [ ] Kullanılan kaynak / varsa YZ desteği ve kendi doğrulama açıklaması.

Eksikler ve nedenleri: [ ]
GitHub aktarımı durumu: [Tamam / Bekliyor]
Kaynak ve YZ kullanım beyanı: [ ]
