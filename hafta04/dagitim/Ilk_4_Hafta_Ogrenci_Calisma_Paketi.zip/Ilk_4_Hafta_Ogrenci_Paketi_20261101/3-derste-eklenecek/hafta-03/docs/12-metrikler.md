# Plan ve gerçekleşen

| Ölçüm | Değer | Tür / açıklama |
| --- | --- | --- |
| İlk seçimin ilk tahmini | [ ] | Plan |
| Yeni bilgi sonrası aynı kapsam | [ ] | Güncel tahmin |
| Güncellenmiş seçimin tahmini | [ ] | Plan |
| Gerçekte DoD geçen iş kimlikleri | [ ] | Kanıta dayalı sonuç |
| Bitmiş işlerin güncel puan toplamı | [ ] | Kanıta dayalı sonuç |
| Çalıştırılan / geçen / kalan test | [ ] | Gerçek gözlem |

Tahmin değişimini nasıl açıklarsın: [ ]
Bu tek simülasyondan neden takım hızı / bireysel verimlilik sonucu çıkarılmaz: [ ]
