# Bireysel çıkış bileti
Bu dosyayı her üye 13-cikis-bileti-U01.md, U02... adıyla kendi kopyası olarak doldurur. G01/G02/G03 beş, G04 dört yanıt teslim eder.
Öğrenci / grup: [ ]
1. Ürün iş listesi ile Sprint için seçilen kapsam arasındaki fark nedir? [ ]
2. Kapasite 8 iken H3-01'in 2'den 3'e çıkması ilk seçimi nasıl etkiler? H3-03 ertelenirse ne olur? [ ]
3. Kod yazıldı ve testler geçti; bağımsız inceleme bekliyor. İş Done olabilir mi? Neden? [ ]
4. Bir kayıt oluşturma, iptalden vazgeçme ve onaylı iptalde toplam kayıt sayısı nasıl değişir? Kendi T06 tablonla açıkla. [ ]
5. Viewed işareti, inceleme kararı ve merge arasındaki fark nedir? [ ]
6. Review ile retrospektif için birer farklı soru örneği yaz. [ ]
Kendi katkım ve gerçek bağlantısı: [ ]
İncelediğim başka kişinin işi: [ ]
Zorlandığım ve düzelttiğim kavram: [ ]
İsteğe bağlı ders-testi.html ilk sonucu / kullandığım ipucu / sonuç dosyası: [ ]
