# Kendi kanıtlarını burada sakla

- E01-pano-baslangic.png: ilk seçilen işler ve durumlar.
- E02-yeni-aciklama.png: kendi çalıştırdığın yeni açıklama.
- E03-iptal-sonucu.png: kendi testindeki iptal kaydı ve açılan saat.
- E04-pano-son.png: gerçek son durum; eksik işleri Done yapma.

Ekran kanıtı yanında tarih, uygulama sürümü ve gözlemi test/teslim belgelerine yaz. Öğretmen görsellerini öğrenci kanıtı diye kullanma. Gerçek GitHub işlemi yapılmadıysa çevrimdışı tabloyu teslim et ve aktarım bekliyor olarak belirt.
