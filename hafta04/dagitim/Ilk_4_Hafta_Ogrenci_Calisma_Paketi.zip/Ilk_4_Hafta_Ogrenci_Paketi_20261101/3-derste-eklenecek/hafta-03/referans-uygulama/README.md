# 1+2. haftadan alınan referans uygulama

Bu klasördeki index.html, önceki başlangıç paketinin aynı kodudur. Mevcut projen varsa kendi index.html dosyanla devam et. Yoksa bu kopyayı yerel çalışma başlangıcı olarak kullan.

3. hafta yönergeleri: ../README.md
3. hafta çıkış testi: ../ders-testi.html
Öğrenci çalışma belgeleri: ../docs/

İptal açıklaması ve onay metni düzenlemesini yalnız kullandığın uygulama kopyasında yap. Kaynak ekranındaki 1–2. hafta ve v0.1 etiketleri önceki prototipe aittir. Çözümlü öğretmen kopyası ayrı pakettedir.

Önceki kaynak paket: https://drive.google.com/drive/folders/1ZxlsAHZy2AW-HIzviFPLHHN69dvjilGq
Lisans: LICENSE
Çalışan özellik ve sınırlar: BILINEN_KISITLAR.md

Gerçek hasta verisi kullanma. Rol seçimi kimlik doğrulama sağlamaz.
