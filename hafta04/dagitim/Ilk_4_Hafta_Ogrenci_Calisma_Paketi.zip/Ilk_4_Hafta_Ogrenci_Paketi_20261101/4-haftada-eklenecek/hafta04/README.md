# 4. hafta - Öğrenci çalışma klasörü

Bu klasörü kendi dolu H3 projenizin köküne ekleyin. Var olan dolu dosyaları boş şablonlarla değiştirmeyin.

1. docs/00 ile kaynak sürümü, yedeği ve gerçek görev paylaşımını kaydedin.
2. docs/01 ile yaklaşım seçimini yazın.
3. docs/02 ve diagrams/01-bilesen.drawio ile tasarımınızı kurun; PNG'yi kendiniz üretin.
4. docs/03 ile ilk planı oluşturun. planlar/00-ornek-plan-girdileri.md yalnız alıştırma girdisidir.
5. İlk planınızı planlar/01-ilk-is-plani.md içine karşılaştırma kopyası olarak alın.
6. İlk plan korununca kartlar/01-karar-tablosu-ve-kanit.md dosyasını uygulayın; güncel hesabı docs/03'e ekleyin.
7. docs/04 ile gerçek farklı kişi incelemesini, varsa düzeltmeyi ve teslimi izleyin.

Detaylı yönerge dağıtım paketinin kökündeki Ilk_4_Hafta_Ogrenci_Takip_Rehberi.pdf dosyasında, 36-49. sayfalardadır.
H4'te kod modüllere ayrılmaz. Kök index.html mevcut H3 uygulamanız olarak kalır.
Bu klasörde öğretmenin doldurulmuş sonuçları veya gerçekleşmiş test/onay kaydı bulunmaz.
