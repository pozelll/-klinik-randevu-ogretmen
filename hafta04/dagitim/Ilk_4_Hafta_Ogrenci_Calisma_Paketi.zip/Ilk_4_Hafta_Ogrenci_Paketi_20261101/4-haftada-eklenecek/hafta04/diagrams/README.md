# Bileşen taslağı

01-bilesen.drawio yalnız düzenlenebilir boş sorumluluk taslağıdır; tamamlanmış mimari değildir. Üç kutuyu kendi senaryonuza göre doldurun, çağrı/sonuç oklarını ve etiketlerini ekleyin. Önerilen tasarım olduğunu yazın.

Düzenledikten sonra aynı dosyayı kaydedin; 01-bilesen.png olarak dışa aktarın. PNG bu pakette hazır verilmedi. İki dosyayı yeniden açıp okunabilirliği ve eşleşmeyi kontrol edin. İlk iki haftanın kök diagrams dosyalarını koruyun.
