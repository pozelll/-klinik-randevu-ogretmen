# 4. hafta - Grubun başlangıç ve sürüm kaydı

Durum: Boş öğrenci şablonu. Öğretmen kaydı değildir.

| Alan | Grubun gerçek kaydı |
|---|---|
| Grup ve üyeler | [Doldurulacak] |
| Kullanılan proje klasörünün tam yolu | [Doldurulacak] |
| H3 kaynak dalı ve tam commit kimliği | [Doldurulacak] |
| Yedek klasör / arşiv ve tarihi | [Doldurulacak] |
| H4 çalışma dalı ve tabanı | [Doldurulacak] |
| Tarayıcı ve uygulama dosyasının yolu | [Doldurulacak] |
| Önceki PR'lar ve açık kalan işler | [Doldurulacak] |
| Depo ve pano bağlantıları | [Doldurulacak] |

## Gerçek görev paylaşımı

| Kişi / hesap | Yazacağı bölüm | İnceleyeceği başka bölüm | Katkı bağlantısı |
|---|---|---|---|
| [Doldurulacak] | [Doldurulacak] | [Doldurulacak] | [Doldurulacak] |

- [ ] Dolu H3 projesi ve yedek ayrı; eski dosyalar korunuyor.
- [ ] Kök index.html aynı uygulamadır; H4 için kod ayrımı yapılmadı.
- [ ] Yerel dosya kaydı ile GitHub commit'i ayrı kontrol edildi.
- [ ] Tarayıcı kayıtlarının dosya yedeğine dahil olmadığı anlaşıldı.

Bu form boşken tamamlanmış başlangıç veya yedek kanıtı sayılmaz.
