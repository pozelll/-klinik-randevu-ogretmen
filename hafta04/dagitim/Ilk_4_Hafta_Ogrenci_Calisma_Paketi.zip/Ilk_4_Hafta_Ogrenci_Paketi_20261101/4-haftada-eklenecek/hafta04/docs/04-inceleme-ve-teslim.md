# 4. hafta - Grubun inceleme ve teslim kaydı

Durum: İnceleme yapılmadı; gerçek işlemden sonra doldurun.

## Paket ve sürüm

- Grup / depo: [Doldurulacak]
- H4 kaynak dalı / hedef dal: [Doldurulacak]
- Önceki PR bağımlılıkları: [Doldurulacak]
- H4 PR bağlantısı: [Doldurulacak]
- İncelenen tam commit SHA ve tarih: [Doldurulacak]
- İnceleyen adı / hesabı: [Doldurulacak]
- İncelediği kapsam ve bu kapsamın yazarı/ortak yazarı olmadığı bilgisi: [Doldurulacak]
- Gerçek inceleme bağlantısı / karar: [Doldurulacak]

## İnceleme kontrolü

- [ ] 00 başlangıç kaydı ve H3 dosyalarının korunması kontrol edildi.
- [ ] 01'de üç yaklaşım ve projeden gerekçeler karşılaştırıldı.
- [ ] 02'de sorumluluklar, iki seçenek, kalıp yararı/maliyeti ve kodda uygulanmamış tasarım ayrımı kontrol edildi.
- [ ] .drawio açılıp deneme kopyasında düzenlendi; PNG aynı tasarımla karşılaştırıldı.
- [ ] 03'te ilk ve güncel süre, emek, öncül, erken/geç, bolluk ve kritik yol yeniden hesaplandı.
- [ ] Aynı kişi için eşzamanlı iki görev olmadığı kontrol edildi.
- [ ] İlk planın sabit kopyası korunuyor; kartın etkisi gerekçeli.
- [ ] Önceki testler ile planlanan yeni kontroller birbirinden ayrılmış.

## Bulgular ve yeniden kontrol

| ID | Dosya/bölüm | Somut bulgu ve önemi | Beklenen düzeltme | Sorumlu ve düzeltme commit'i | Yeniden inceleyen / sonuç |
|---|---|---|---|---|---|
| [Doldurulacak] | [Doldurulacak] | [Doldurulacak] | [Doldurulacak] | [Doldurulacak] | [Doldurulacak] |

## Birleştirme ve teslim

- Engelleyici bulgular / mevcut durum: [Doldurulacak]
- Doğru hedef dal, bağımlılık ve fark kontrolü: [Doldurulacak]
- Gerçek birleştirme commit'i ve tarih (yoksa Bekliyor): [Doldurulacak]
- Ana sürümde son dosya/bağlantı kontrolü: [Doldurulacak]
- Teslim paketi / depo bağlantısı ve sürüm: [Doldurulacak]
- Öğretmenin erişim kontrolü: [Doldurulacak]
- Kalan işler: [Doldurulacak]

İnceleme yapılmadıysa Bekliyor yazın. Viewed, hazırlanmış form, açılmış PR veya yüklenmiş dosya tek başına bağımsız inceleme ve teslim değildir. Bu belge H4 tasarım/plan incelemesidir; beşinci haftadaki uygulama ve kod incelemesi henüz yapılmış sayılmaz.
