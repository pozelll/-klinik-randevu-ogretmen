# H4 alıştırması - İlk plan girdileri

Bu tablo yalnız ders için verilen girdilerdir; yapılmış iş veya ölçülmüş grup tahmini değildir. Bir blok 30 dakika; t=0 net çalışma başlangıcıdır. U1-U4 örnek kişilerdir. Öncüller bitmeden sonraki iş başlamaz. B/C/D farklı kişilerle paralel yapılabilir. Atanan her kişi bütün görev süresince o işe katılır. U4 kodun yazarı değildir. H iki blokla sınırlı düzeltme payıdır; dış onay beklemesi bu net süre hesabında yoktur.

| İş ID | Somut görev / çıktı | Öncül iş(ler) | Sorumlu(lar) | Süre: blok (saat) |
| --- | --- | --- | --- | ---: |
| A | Ortak sözleşmeyi, örnek kayıtları ve uygulamayı açma yöntemini netleştir; deneme koşullarını yaz. | Yok | U1 + U2 | 2 (1) |
| B | Randevu Deposu erişimini hazırla: kayıt kopyası, okuma, güncelleme, eski veri biçimi ve kalıcılık sonucu. | A | U1 | 4 (2) |
| C | İptal uygunluğunu, durum geçişini ve BR-01 sonucunu ekran/kayıt ayrıntılarından ayır. | A | U2 | 3 (1,5) |
| D | Onay/vazgeçme, sonuç mesajı ve görünüm akışını kararlaştırılan işlem sonuçlarına bağla. | A | U3 | 3 (1,5) |
| E | Üç parçayı birleştir; açılışı ve oluşturma/tamamlama ile ortak güncel veri kullanımını kontrol et. | B, C, D | U1 + U2 + U3 | 2 (1) |
| F | Kabul ve sınır denemelerini çalıştır; gerçek sonuçları, kayıt kimliklerini ve bulguları kaydet. | E | U2 + U3 | 3 (1,5) |
| G | Yazarlardan farklı üye kodu, test kayıtlarını ve mimari uyumu incelesin; bulguları yazsın. | F | U4 | 2 (1) |
| H | Sınırlı bulgu düzeltmesi ve ilgili denemelerin tekrarı için ayrılan çalışma. | G | U1 + U2 | 2 (1) |
| I | İnceleyenle son durumu doğrula; uygun teslim adayını commit, test ve inceleme kayıtlarıyla paketle. | H | U1 + U4 | 1 (0,5) |

Erken/geç zamanları, bolluğu, kritik yolu, toplam emeği ve kişi çakışmalarını siz hesaplayın. Beş kişilik grup ek kişiye somut görev atamadan süreyi kısaltamaz. Kendi planınızı kullanırsanız bütün varsayımları ve farkları açıklayın.
