# Grubun ilk planının sabit karşılaştırma kopyası

Durum: Henüz ilk plan eklenmedi. Bu dosya hazır plan değildir.

- Grup: [Doldurulacak]
- İlk plan tarihi ve kaynak commit: [Doldurulacak]
- Kontrol eden kişi / yorum: [Doldurulacak]

Altıncı basamak bittiğinde docs/03 içindeki ilk planın kapsamını, varsayımlarını, görev/süre/kişi/öncül tablosunu, ağını, erken-geç ve bolluk hesabını, net süre/emeği ve risklerini buraya kopyalayın. Gerekli göreli bağlantıları bu konuma göre düzeltin.

Yedinci basamakta bu kopyanın üstüne yeni değer yazmayın. Kartı ve güncel planı docs/03'te tutun.
