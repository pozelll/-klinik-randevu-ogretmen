# H4 - İsteğe bağlı tekrar soruları

Bu dosya ek zorunlu teslim veya yeni notlandırma eşiği değildir.

Ad / grup: [Doldurulacak]

1. H3 dosyasını neden koruduk? Tarayıcı verisi de kopyalanır mı?
2. Artırımlı ve çevik yaklaşım birlikte kullanılabilir mi? Projenizden gerekçe verin.
3. İptal kararında arayüz, iş kuralları ve veri erişiminin görevleri nedir?
4. Seçtiğiniz kalıbın somut yararı ve ek maliyeti nedir?
5. Süre ile kişi-saat emeğini bir örnekle ayırın.
6. Kendi planınızın kritik yolunu ve bir birleşme noktasının hesabını açıklayın.
7. Yeni kartta hangi işler değişti; bolluk net bitişi nasıl etkiledi?
8. Yükleme, PR, review ve merge farkını kendi bağlantılarınızla açıklayın.

Yanıtlar: [Kendi cümlelerinizle doldurun]
