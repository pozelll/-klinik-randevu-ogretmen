# İlk dört hafta - Öğrenci çalışma paketi

Sürüm: 1 Kasım 2026. Dört grup: G01/G02/G03 beşer, G04 dört kişi.

## Devam eden grup

Kendi dolu projenizi yedekleyin. İlk üç haftayı yaptıysanız yeniden boş başlangıçtan başlamayın. Yalnız 4-haftada-eklenecek/hafta04 klasörünü kendi proje kökünüze ekleyin. Kendi dolu hafta04 dosyanız varsa karşılaştırarak ilerleyin; üzerine boş kopya yazmayın.

## Yeni başlayan grup

1. ZIP'in tamamını çıkarın.
2. klinik-randevu-ogrenci klasöründeki index.html dosyasını açın; PDF'in ilk üç ders bölümünü izleyin.
3. Üçüncü haftada 3-derste-eklenecek içindeki hafta-03 klasörünü aynı proje köküne alın. Kod parçalarını yönergeyle kendi kök index.html dosyanıza uygulayın.
4. Dördüncü haftada 4-haftada-eklenecek içindeki hafta04 klasörünü aynı köke ekleyin.

İlk üç dersin uygulaması ve şablonları 29 Ekim dağıtım paketinden değiştirilmeden korundu. H3 referans-uygulama tamamlanmış örnek olarak önceki pakette vardı; grubunuzun kendi kod değişikliği ve testinin yerine geçmez. Bu pakete öğretmenin dolu H4 belgeleri, gerçek inceleme onayı veya H4 çözülmüş kritik yol hesabı konmadı.

## Dosyalar

- Ilk_4_Hafta_Ogrenci_Takip_Rehberi.pdf: 49 sayfa; ilk üç ders sayfa 3-35, H4 sayfa 36-49.
- klinik-randevu-ogrenci/: başlangıç uygulaması, ilk iki dersin boş belgeleri ve modelleri.
- 3-derste-eklenecek/hafta-03/: eski H3 şablonları, görev metinleri, kod parçaları ve alıştırma.
- 4-haftada-eklenecek/hafta04/: yeni boş belgeler, düzenlenebilir çizim taslağı, plan girdileri ve değişiklik kartı.

Yerel dosya kopyası tarayıcı randevu kayıtlarının yedeği değildir. Aynı tarayıcı ve dosya yolunu kaydedin. Gerçek hasta verisi kullanmayın; veri eğitim için sentetiktir.

Kendi grup deponuzda çalışın. Öğretmen deposu örnektir:
https://github.com/pozelll/-klinik-randevu-ogretmen/tree/docs/h4-mimari-plan

H4'te kod ayrımı yapılmaz. Gerçek inceleme/teslim eksikse Bekliyor yazın. Rehberdeki örnek sayıları gerçek sonuç yerine koymayın.
