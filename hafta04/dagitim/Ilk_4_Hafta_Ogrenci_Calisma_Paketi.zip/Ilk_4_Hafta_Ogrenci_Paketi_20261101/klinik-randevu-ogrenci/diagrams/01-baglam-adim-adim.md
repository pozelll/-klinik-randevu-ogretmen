# Bağlam diyagramı - yardımcı çizim rehberi
Bu dosya sonradan eklenen yardımcı rehberdir; diagrams klasöründe tutulur. Yeni bir ek ödev değildir.
1. app.diagrams.net açın. Konum sorulursa Device seçin; üyelik gerekmez.
2. 01-baglam.drawio dosyasını File > Open From > Device ile açın.
3. Sistemi tek kutuda; Hasta, Resepsiyon, Doktor'u dışarıda gösterin. Giden isteği ve dönen bilgiyi adlandırın.
4. Metni bitirmek için boş alana tıklayın veya Esc kullanın. Enter satır ekleyebilir; dosya kaydetmez.
5. File > Save / Ctrl+S ile .drawio kaydedin. Gerekirse File > Save As kullanın; tarayıcının indirdiği dosyayı diagrams içine koyun.
6. File > Export As > PNG ile 01-baglam.png üretin. Her iki dosyayı yeniden açıp okunabilirliği kontrol edin.
