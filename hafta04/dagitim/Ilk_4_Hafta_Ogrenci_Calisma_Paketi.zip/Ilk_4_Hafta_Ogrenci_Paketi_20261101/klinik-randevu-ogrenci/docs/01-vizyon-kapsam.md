# 01 — Vizyon ve kapsam

Ekip: [ ]  
Tarih: [ ]  
Sürüm: [ ]  
İlgili issue / PR: [ ]

## Problem

[Hangi kullanıcı hangi işi yapmakta zorlanıyor? Çözümü tarif etmeden problemi iki cümleyle yazın.]

## Kullanıcıya sağlayacağı değer

[ ]

## Kapsam içinde

- [ ]
- [ ]
- [ ]

## Kapsam dışında

- [ ]
- [ ]
- [ ]

## Başarıyı nasıl gözleyeceğiz?

| Kullanıcı amacı | Gözlenebilir başarı kanıtı | Kim kontrol edecek? |
|---|---|---|
| [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] |

## Varsayımlar ve açık sorular

- Varsayım: [ ]
- Paydaşa sorulacak soru: [ ]
