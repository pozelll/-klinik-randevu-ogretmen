# 02 — Paydaşlar, ihtiyaçlar ve sorular

Ekip: [ ]  
Tarih: [ ]

| Paydaş | Sistemden beklediği sonuç | Soracağımız soru | Henüz doğrulanmayan varsayım |
|---|---|---|---|
| Hasta | [ ] | [ ] | [ ] |
| Resepsiyon (sekreter) | [ ] | [ ] | [ ] |
| Doktor | [ ] | [ ] | [ ] |
| [Ek paydaş; gerekçesiyle] | [ ] | [ ] | [ ] |

## Rol ve işlem tablosu

Prototipte gördüğünüzü yazın. Bu gözlem, gerçek kurumun onaylanmış yetki tasarımı değildir.

| İşlem | Hasta | Resepsiyon | Doktor | Paydaşa sorulacak nokta |
|---|---|---|---|---|
| Uygun saatleri görüntüleme | [ ] | [ ] | [ ] | [ ] |
| Randevu oluşturma | [ ] | [ ] | [ ] | [ ] |
| Kendi randevusunu iptal etme | [ ] | [ ] | [ ] | [ ] |
| Günlük listeyi görüntüleme | [ ] | [ ] | [ ] | [ ] |
| Tamamlandı işlemi | [ ] | [ ] | [ ] | [ ] |
| Günlük toplamlar | [ ] | [ ] | [ ] | [ ] |

## Görüşme notu

- Soru: [ ]
- Alınan yanıt / öğretmenin senaryo yanıtı: [ ]
- Bu yanıtın kapsam üzerindeki etkisi: [ ]
