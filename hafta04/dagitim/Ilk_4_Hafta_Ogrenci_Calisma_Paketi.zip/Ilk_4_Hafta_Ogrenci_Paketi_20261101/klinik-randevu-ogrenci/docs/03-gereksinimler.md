# 03 — Gereksinim taslağı

Ekip: [ ]  
Sürüm: [ ]  
İnceleyen: [ ]

Her satırda sistemin yapacağı işi açık ve kontrol edilebilir biçimde yazın. Ekrandaki düğme adı tek başına gereksinim değildir. Önceliğinizi ve gerekçenizi ekleyin.

## İşlevsel gereksinimler

| Kimlik | Başlık | Sistem ne yapmalı? | Aktör / koşul | Öncelik ve gerekçe |
|---|---|---|---|---|
| FR-01 | Uygun saatleri listeleme | [ ] | [ ] | [ ] |
| FR-02 | Randevu oluşturma | [ ] | [ ] | [ ] |
| FR-03 | Kendi randevusunu iptal etme | [ ] | [ ] | [ ] |
| FR-04 | Yetkili günlük liste | [ ] | [ ] | [ ] |
| FR-05 | Doktorun randevuyu tamamlaması | [ ] | [ ] | [ ] |
| FR-06 | Yetkili günlük toplamlar | [ ] | [ ] | [ ] |

## Kalite gereksinimleri — öğrenci taslağı

Bu satırlar uygulamanın ölçülmüş özellikleri değildir. Ekip, ölçüyü ve değerlendirme yöntemini seçerek taslak gereksinim yazar.

| Kimlik | Kalite konusu | Ölçülebilir hedef | Ölçüm koşulu | Nasıl kontrol edilecek? |
|---|---|---|---|---|
| NFR-01 | Kullanılabilirlik | [ ] | [ ] | [ ] |
| NFR-02 | Yanıt süresi | [ ] | [ ] | [ ] |
| NFR-03 | Erişilebilirlik | [ ] | [ ] | [ ] |

## Başlangıçta verilmiş iş kuralı

**BR-01:** Aynı doktor, tarih ve saat için iptal edilmemiş ikinci randevu oluşturulamaz. Bu prototipte Bekliyor ve Tamamlandı kayıtları saati kapatır; İptal edildi kaydı saati serbest bırakır. Kontrol aynı açık sayfanın mevcut veri durumu içindir; çoklu sekme/cihaz garantisi değildir.

- BR-01 hangi işlevleri etkiliyor? [ ]
- Bu kural için paydaşa soracağımız soru: [ ]
- Gözlemlediğimiz başka kural: [ ]

## Belirsiz ifadeyi düzeltme

- Belirsiz ifade: [ ]
- Daha açık, kontrol edilebilir ifade: [ ]
- Eksik bilgi / doğrulama sorusu: [ ]


## Ders için verilen kalite hedefleri
NFR-01: Dört farklı kişiden en az üçü iptali onaylama ve vazgeçme görevlerinin ikisini de doğru, yardımsız, her görevde en çok 60 saniyede tamamlar.
NFR-02: Aynı cihaz ve tarayıcıda, en çok 20 kayıtla, Resepsiyon rolünde 10 doktor değişiminin tamamında B1/B2/B3 doğru biçimde en çok 1 saniyede güncellenir.
NFR-03: Oluşturma, vazgeçme, iptal ve doktorun tamamlama görevlerinin dördü de yalnız klavyeyle, görünür odakla, tuzakta kalmadan tamamlanır.
Bu hedeflerin ölçüm yöntemini yukarıya yazın. Ölçülmediyse sonucu Ölçülmedi bırakın.
