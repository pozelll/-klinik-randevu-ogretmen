# 04 — Kabul koşulları

Ekip: [ ]  
Sürüm: [ ]

**Verilen (Given):** Başlangıç durumu ve gerekli veri.  
**Ne zaman (When):** Kullanıcının tek belirgin eylemi.  
**O zaman (Then):** Dışarıdan gözlenebilir beklenen sonuç.

Beklenen sonuç önceden yazılır. Gerçek sonuç ancak uygulamayı deneyince yazılır. Henüz denenmediyse “Çalıştırılmadı” yazın.

| Kimlik | Gereksinim | Verilen | Ne zaman | O zaman | Gerçek sonuç | Durum |
|---|---|---|---|---|---|---|
| AC-01 | FR-01 | [ ] | [ ] | [ ] | [ ] | Çalıştırılmadı |
| AC-02 | FR-02 | [ ] | [ ] | [ ] | [ ] | Çalıştırılmadı |
| AC-03 | FR-03 | [ ] | [ ] | [ ] | [ ] | Çalıştırılmadı |
| AC-04 | FR-04 | [ ] | [ ] | [ ] | [ ] | Çalıştırılmadı |
| AC-05 | FR-05 | [ ] | [ ] | [ ] | [ ] | Çalıştırılmadı |
| AC-06 | FR-06 | [ ] | [ ] | [ ] | [ ] | Çalıştırılmadı |
| AC-07 | BR-01 | [ ] | [ ] | [ ] | [ ] | Çalıştırılmadı |

## ALT-01 - İptal işleminden vazgeçme

- İlgili FR / BR: [ ]
- Verilen: [ ]
- Ne zaman: [ ]
- O zaman: [ ]
- Bu sonuç oluşmasaydı kullanıcı ne yaşardı? [ ]

## Kalite kabul planı
| Kimlik | Hedef bağlantısı | Başlangıç koşulu ve ölçüm yöntemi | Gerçek sonuç | Durum |
|---|---|---|---|---|
| AC-NFR-01 | NFR-01 | [ ] | [ ] | Ölçülmedi |
| AC-NFR-02 | NFR-02 | [ ] | [ ] | Ölçülmedi |
| AC-NFR-03 | NFR-03 | [ ] | [ ] | Ölçülmedi |
