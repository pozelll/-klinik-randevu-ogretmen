# 06 — Riskler

Ekip: [ ]  
Tarih: [ ]

Risk, gerçekleşmesi kesin olmayan ve amacı etkileyebilecek bir durumdur. Ortaya çıkmış sorunları ayrıca issue olarak kaydedin.

| Kimlik | Risk ve nedeni | Olasılık: düşük/orta/yüksek | Etki | Erken işaret | Önlem | Sorumlu |
|---|---|---|---|---|---|---|
| RSK-01 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| RSK-02 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| RSK-03 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## Bir riski gözden geçirme

- Önceki değerlendirme: [ ]
- Yeni kanıt: [ ]
- Güncel karar: [ ]
- Bir sonraki kontrol tarihi: [ ]
