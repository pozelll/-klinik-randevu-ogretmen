# 07 — Kısa ekip toplantısı

Tarih ve süre: [ ]  
Katılanlar: [ ]  
Notu yazan: [ ]

## Bugünkü amaç

[ ]

## Görüşülen konular

- [ ]
- [ ]

## Kararlar

| Karar | Gerekçe | İlgili FR / Issue | Sorumlu | Hedef tarih |
|---|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] | [ ] |
| [ ] | [ ] | [ ] | [ ] | [ ] |

## Açık kalan soru

[ ]

## Bir sonraki küçük hedef

[ ]
