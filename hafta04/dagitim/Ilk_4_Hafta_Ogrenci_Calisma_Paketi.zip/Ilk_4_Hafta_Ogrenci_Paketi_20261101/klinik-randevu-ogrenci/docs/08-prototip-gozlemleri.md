# 08 — Prototip gözlemleri

Ekip: [ ]  
Tarayıcı: [ ]  
İncelenen sürüm: [ ]  
Kullanılan aynı dosya yolu ve mevcut referans kayıt: [ ]
Önceki kayıtlar korunur. Yeni başlangıç mı, önceki oturumun devamı mı? [ ]

“Gördüm” ile “olmasını istiyorum” ifadelerini ayırın. Gerçekleşmeyen bir sonucu gözlenmiş gibi yazmayın.

| No | Rol / hasta / doktor / tarih | Uygulanan adımlar | Beklenen | Gözlenen | Ekran alanı B1/B2/B3 | Soru veya yorum |
|---|---|---|---|---|---|---|
| G-01 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| G-02 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| G-03 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| G-04 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| G-05 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| G-06 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| G-07 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## Kayıt davranışı

- Ekranın altındaki Kaydetme açıklaması: [ ]
- Sayfa yenilenince gözlediğimiz davranış: [ ]
- Bu gözlemin başka cihaz veya tarayıcı için neden aynı sonucu garanti etmediği: [ ]

## Paydaşa götürülecek üç soru

1. [ ]
2. [ ]
3. [ ]
