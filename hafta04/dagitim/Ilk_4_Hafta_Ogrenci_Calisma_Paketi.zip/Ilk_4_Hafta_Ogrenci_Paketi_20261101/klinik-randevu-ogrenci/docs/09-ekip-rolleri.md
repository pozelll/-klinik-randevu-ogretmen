# Ekip rolleri ve katkı planı
Grup: [G01 / G02 / G03 / G04] | Tarih: [ ]
G01, G02, G03: beşer kişi. G04: dört kişi.

| Üye | Ad / GitHub kullanıcı adı | İlk iki dersin sorumluluğu | Somut katkı ve bağlantı | Başka kimin işini inceledi? |
|---|---|---|---|---|
| 1 | [ ] | Koordinasyon, depo ve pano; README, docs/07 | [ ] | [ ] |
| 2 | [ ] | İhtiyaç, kapsam, gereksinimler; docs/01-03 | [ ] | [ ] |
| 3 | [ ] | Diyagramlar ve izlenebilirlik; diagrams, docs/05 | [ ] | [ ] |
| 4 | [ ] | Prototip gözlemi ve kabul; docs/04, docs/08 | [ ] | [ ] |
| 5 | [ ] | Risk, kontrol ve inceleme; docs/06 | [ ] | [ ] |

G04 için: Üye 1 koordinasyon; Üye 2 gereksinimler + diyagramlar + izlenebilirlik; Üye 3 gözlem + kabul; Üye 4 risk + inceleme. Üye 1 çizim ve yükleme işinde Üye 2'ye destek olur. G04, beşinci satırı kullanmaz.
Her üye kendi hesabıyla somut katkı yapar. Aynı kişi kendi değişikliğinin bağımsız inceleyeni olmaz. Sorumluluk, diğer üyelerin katılmayacağı anlamına gelmez.

## Ekip anlaşması
- Dal adlandırma kuralı: [ ]
- Tamamlanma koşulumuz: [ ]
- Dosyayı düzenleyen / farklı kişi kontrol eden: [ ]
- Engel olduğunda yardım isteme biçimi: [ ]
- Depo ve Projects erişimini kontrol eden: [ ]
- Üçüncü derste görev dönüşümü: [ ]
